﻿CREATE TABLE [dbo].[SinhVien] (
    [MaSV]     NVARCHAR (10) NOT NULL,
    [TenSV]    NVARCHAR (100) NULL,
    [GioiTinh] NVARCHAR (10) NULL,
    [NgaySinh] DATETIME      NULL,
    [QueQuan]  NVARCHAR (100) NULL,
    [MaLop]    NVARCHAR (10) NULL,
    PRIMARY KEY CLUSTERED ([MaSV] ASC)
);

