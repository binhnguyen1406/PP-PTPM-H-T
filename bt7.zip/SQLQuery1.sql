﻿CREATE TABLE Lop (
    MaLop NVARCHAR(10) PRIMARY KEY,
    TenLop NVARCHAR(50)
);

-- Thêm vài lớp mẫu để test
INSERT INTO Lop VALUES ('CNPM1', N'Công nghệ phần mềm 1');
INSERT INTO Lop VALUES ('CNPM2', N'Công nghệ phần mềm 2');
INSERT INTO Lop VALUES ('CNTT1', N'Công nghệ thông tin 1');
